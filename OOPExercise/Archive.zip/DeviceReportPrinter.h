#ifndef DEVICEREPORTPRINTER
#define DEVICEREPORTPRINTER

#include <string>
#include <unordered_map>
#include <vector>
#include <algorithm>

class IFormatter;
class Device;
class Device;

/*
* DISCLAIMER
* 
* 1) This source code has been provided as-is for the purpose of learning 
* 2) The code snippet/samples shown here are only meant to highlight concepts provided in the training
*    They may not cover all important, clean coding & best practices like documentation comments or naming conventions (e.g., PC-Lint rules)
* 3) Some part of code/class abstractions may have been intentionally edited
*/

/// <summary>
/// This is an important class which prints out the report for the list
/// of devices as per the given IFormatter interface implementation.
/// The report contains a header, status for all devices, count for each type of Device and the total device count 
/// 
/// </summary>
class DeviceReportPrinter
{
private:
	IFormatter *formatter;
	std::vector<Device*> devices;

public:
	virtual ~DeviceReportPrinter()
	{
		delete formatter;
	}
	virtual std::string generate(IFormatter *formatter, std::vector<Device*> &devices);

private:
	std::string asReport();

	DeviceReportPrinter *createHeader();

	DeviceReportPrinter *appendDeviceStatuses();

	DeviceReportPrinter *appendDeviceTotalCount();

	DeviceReportPrinter *appendDeviceTypeCounts();
};

#endif	//#ifndef DEVICEREPORTPRINTER
