#include "MedicalDevice.h"

MedicalDevice::MedicalDevice(int deviceId) : Device(deviceId)
{
}

int MedicalDevice::getHeartRate()
{
	 return heartRate;
}

void MedicalDevice::setHeartRate(int value)
{
	  heartRate = value;
}

std::string MedicalDevice::getStatus()
{
	return std::to_string(getHeartRate());
}

std::string MedicalDevice::getDeviceType()
{
	return "Medical";
}
