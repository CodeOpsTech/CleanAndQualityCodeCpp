#include "AgriculturalDevice.h"

AgriculturalDevice::AgriculturalDevice(int deviceId) : Device(deviceId)
{
}

int AgriculturalDevice::getSoilQuality()
{
	 return soilQuality;
}

void AgriculturalDevice::setSoilQuality(int value)
{
	soilQuality = value;
}

std::string AgriculturalDevice::getStatus()
{
	return std::to_string(getSoilQuality());
}

std::string AgriculturalDevice::getDeviceType()
{
	return "Agricultural";
}
