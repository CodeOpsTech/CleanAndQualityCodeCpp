#include "HtmlReportBody.h"
#include "StringBuilder.h"

HtmlReportBody::HtmlReportBody() : htmlBodyBuilder(new StringBuilder())
{
}

IReportBodyFormatter *HtmlReportBody::appendContent(const std::string &content)
{
	appendLineBreak();
	htmlBodyBuilder->append(content);
	return this;
}

std::string HtmlReportBody::toReportString()
{
	return htmlBodyBuilder->toString();
}

void HtmlReportBody::appendLineBreak()
{
	htmlBodyBuilder->append("<BR/>");
}
