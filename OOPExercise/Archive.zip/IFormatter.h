#ifndef IFORMATTER
#define IFORMATTER

#include <string>

#include "IReportBodyFormatter.h"

/*
* DISCLAIMER
* 
* 1) This source code has been provided as-is for the purpose of learning 
* 2) The code snippet/samples shown here are only meant to highlight concepts provided in the training
*    They may not cover all important, clean coding & best practices like documentation comments or naming conventions (e.g., PC-Lint rules)
* 3) Some part of code/class abstractions may have been intentionally edited
*/

/*
 * Interface to perform formatting of the report in the Header-Body-HTML string conversion format 
 * */
class IFormatter
{
public:
	virtual void setHeader(const std::string &header) = 0;
	virtual IReportBodyFormatter *getReportBody() = 0;
	virtual std::string toReportString() = 0;
};

#endif	//#ifndef IFORMATTER
