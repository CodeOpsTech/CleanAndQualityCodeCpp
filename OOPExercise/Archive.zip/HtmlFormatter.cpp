#include "HtmlFormatter.h"
#include "HtmlReportBody.h"
#include "IReportBodyFormatter.h"

HtmlFormatter::HtmlFormatter() : reportBody(new HtmlReportBody())
{
}

void HtmlFormatter::setHeader(const std::string &text)
{
	header = std::string("<H1> ") + text + std::string(" </H1>");
}

IReportBodyFormatter *HtmlFormatter::getReportBody()
{
	return reportBody;
}

std::string HtmlFormatter::toReportString()
{
	return header + reportBody->toReportString();
}
