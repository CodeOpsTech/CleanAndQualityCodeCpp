#include <boost/locale.hpp> 

#include "DeviceReportPrinter.h"
#include "IFormatter.h"
#include "Device.h"
#include "Device.h"

using namespace boost; 

std::string DeviceReportPrinter::asReport()
{
	return formatter->toReportString();
}

DeviceReportPrinter *DeviceReportPrinter::createHeader()
{
	formatter->setHeader(devices.empty() ? locale::translate("EmptyList").str() : locale::translate("DeviceReport").str()); 
	return this;
}

DeviceReportPrinter *DeviceReportPrinter::appendDeviceStatuses()
{
	for (auto device : devices)
	{
		formatter->getReportBody()->appendContent(locale::translate("DeviceID").str() 
							   + std::string(" : ") 
							   + std::to_string(device->getDeviceId()) 
							   + std::string("; ") 
							   + device->getStatus());
	}
	return this;
}

DeviceReportPrinter *DeviceReportPrinter::appendDeviceTotalCount()
{
	formatter->getReportBody()->appendContent(locale::translate("Total").str() 
						   + std::string(": "))->appendContent(std::to_string(devices.size()) 
						   + std::string(" "))->appendContent(locale::translate("Devices").str());
	return this;
}

DeviceReportPrinter *DeviceReportPrinter::appendDeviceTypeCounts()
{
	std::unordered_map<std::string, int> deviceTypeDictionary;
	for (auto device : devices)
	{
		if (deviceTypeDictionary.find(device->getDeviceType()) != deviceTypeDictionary.end())
		{
			std::string type = device->getDeviceType();
			int count = static_cast<int>(deviceTypeDictionary[type]);
			deviceTypeDictionary.at(type) = ++count;
		}
		else
		{
			deviceTypeDictionary[locale::translate(device->getDeviceType()).str()] = 1;
		}
	}

	std::vector<std::string> keys; keys.reserve(deviceTypeDictionary.size());
	std::vector<int> vals; vals.reserve(deviceTypeDictionary.size());

	for(auto kv : deviceTypeDictionary) {
        	keys.push_back(kv.first);
        	vals.push_back(kv.second);  
    	} 
    
	std::for_each(keys.begin(), keys.end(), ([&] (std::string &item)
	{
		formatter->getReportBody()->appendContent(item + std::string(": ") 
					                       + std::to_string(static_cast<int>(deviceTypeDictionary[item])) 
							       + locale::translate("Devices").str());
	}));
	return this;
}

std::string DeviceReportPrinter::generate(IFormatter *formatter, std::vector<Device*> &devices)
{
	this->formatter = formatter;
	this->devices = devices;

	return createHeader()
		->appendDeviceStatuses()
		->appendDeviceTypeCounts()
		->appendDeviceTotalCount()
		->asReport();
}
