#ifndef DEVICE
#define DEVICE

#include <string>

/*
* DISCLAIMER
* 
* 1) This source code has been provided as-is for the purpose of learning 
* 2) The code snippet/samples shown here are only meant to highlight concepts provided in the training
*    They may not cover all important, clean coding & best practices like documentation comments or naming conventions (e.g., PC-Lint rules)
* 3) Some part of code/class abstractions may have been intentionally edited
*/

/* An abstract base class which represents the concept of a "Device"
 * It contains common functionality such as toggling device status 
 * and various properties/accessors for Device Id and Device Type.  
 * */
class Device
{
private:
	bool onOff = false;
	int deviceId = 0;

protected:
	Device(int deviceId);

public:
	virtual bool getOnOff();

private:
	void setOnOff(bool value);

public:
	virtual int getDeviceId();

	virtual std::string getDeviceType() = 0;

	virtual void toggleStatus();

	virtual std::string getStatus() = 0;
};

#endif	//#ifndef DEVICE
