#ifndef HTMLREPORTBODY
#define HTMLREPORTBODY

#include "IReportBodyFormatter.h"
#include <string>
#include "stringbuilder.h"

class IReportBodyFormatter;
class StringBuilder;

/*
* DISCLAIMER
* 
* 1) This source code has been provided as-is for the purpose of learning 
* 2) The code snippet/samples shown here are only meant to highlight concepts provided in the training
*    They may not cover all important, clean coding & best practices like documentation comments or naming conventions (e.g., PC-Lint rules)
* 3) Some part of code/class abstractions may have been intentionally edited
*/

/*
 * Generates the report body in HTML format - this class incrementally builds up 
 * the report body and is an example of the Builder pattern 
 * */
class HtmlReportBody : public IReportBodyFormatter
{
private:
	StringBuilder *const htmlBodyBuilder;

public:
	virtual ~HtmlReportBody()
	{
		delete htmlBodyBuilder;
	}

	HtmlReportBody();

	virtual IReportBodyFormatter *appendContent(const std::string &content) override;

	virtual std::string toReportString() override;

   private:
	void appendLineBreak();
};

#endif	//#ifndef HTMLREPORTBODY
