#include "Device.h"

Device::Device(int deviceId)
{
	this->deviceId = deviceId;
}

bool Device::getOnOff()
{
	return onOff;
}

void Device::setOnOff(bool value)
{
	onOff = value;
}

int Device::getDeviceId()
{
	return deviceId;
}

void Device::toggleStatus()
{
	onOff = !onOff;
}
