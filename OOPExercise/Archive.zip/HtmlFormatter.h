#ifndef HTMLFORMATTER
#define HTMLFORMATTER

#include "IFormatter.h"
#include <string>

class IReportBodyFormatter;

/*
* DISCLAIMER
* 
* 1) This source code has been provided as-is for the purpose of learning 
* 2) The code snippet/samples shown here are only meant to highlight concepts provided in the training
*    They may not cover all important, clean coding & best practices like documentation comments or naming conventions (e.g., PC-Lint rules)
* 3) Some part of code/class abstractions may have been intentionally edited
*/

/*
 * Implements HTML specific formatting logic to generate the report as per the IFormatter interface
 * Internally uses the HTML Report Body class to generate the body, and adds the header and body content 
 * */
 
class HtmlFormatter : public IFormatter
{
private:
	std::string header;
	IReportBodyFormatter *const reportBody;

public:
	virtual ~HtmlFormatter()
	{
		delete reportBody;
	}

	HtmlFormatter();

	virtual void setHeader(const std::string &text) override;

	virtual IReportBodyFormatter *getReportBody() override;

	virtual std::string toReportString() override;
};

#endif	//#ifndef HTMLFORMATTER
