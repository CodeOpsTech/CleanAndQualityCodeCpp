#include "RefineryDevice.h"

RefineryDevice::RefineryDevice(int deviceId) : Device(deviceId)
{
}

int RefineryDevice::getTemperature()
{
	 return temperature;
}

void RefineryDevice::setTemperature(int value)
{
	temperature = value;
}

std::string RefineryDevice::getStatus()
{
	return std::to_string(getTemperature());
}

std::string RefineryDevice::getDeviceType()
{
	return "Refinery";
}
