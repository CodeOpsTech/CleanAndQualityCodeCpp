#ifndef REFINERYDEVICE
#define REFINERYDEVICE

#include "Device.h"
#include <string>

/*
* DISCLAIMER
* 
* 1) This source code has been provided as-is for the purpose of learning 
* 2) The code snippet/samples shown here are only meant to highlight concepts provided in the training
*    They may not cover all important, clean coding & best practices like documentation comments or naming conventions (e.g., PC-Lint rules)
* 3) Some part of code/class abstractions may have been intentionally edited
*/

/*
 * Represents a Refinery Device 
 * */
class RefineryDevice : public Device
{
private:
	int temperature = 0;

public:
	RefineryDevice(int deviceId);

	virtual int getTemperature();

	virtual void setTemperature(int value);

	virtual std::string getStatus() override;

	virtual std::string getDeviceType() override;
};

#endif	//#ifndef REFINERYDEVICE
