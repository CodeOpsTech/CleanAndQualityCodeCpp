#include <string>
#include <vector>
#include <iostream>

#include <boost/locale.hpp> 

#include "Device.h"
#include "AgriculturalDevice.h"
#include "MedicalDevice.h"
#include "RefineryDevice.h"
#include "DeviceReportPrinter.h"
#include "HtmlFormatter.h"

/*
* DISCLAIMER
* 
* 1) This source code has been provided as-is for the purpose of learning 
* 2) The code snippet/samples shown here are only meant to highlight concepts provided in the training
*    They may not cover all important, clean coding & best practices like documentation comments or naming conventions (e.g., PC-Lint rules)
* 3) Some part of code/class abstractions may have been intentionally edited
*/

int main(int argc, const char** argv)
{
        boost::locale::generator gen;
        gen.add_messages_path(".");
        gen.add_messages_domain("DeviceResources");
        std::locale::global(gen("nl_NL"));
        // std::locale::global(gen("en_US"));

	// here is a test code to drive the program 
	std::vector<Device*> devices;

	AgriculturalDevice *agri = new AgriculturalDevice(1);
	agri->setSoilQuality(30);
	devices.push_back(agri);

	MedicalDevice *med = new MedicalDevice(2);
	med->setHeartRate(75);
	devices.push_back(med);

	RefineryDevice *refinery = new RefineryDevice(3);
	refinery->setTemperature(100);
	devices.push_back(refinery);

	std::vector<Device*> noDevices;

	DeviceReportPrinter* tempVar = new DeviceReportPrinter();
	HtmlFormatter* tempVar2 = new HtmlFormatter();
	std::cout << tempVar->generate(tempVar2, devices) << std::endl;
}
