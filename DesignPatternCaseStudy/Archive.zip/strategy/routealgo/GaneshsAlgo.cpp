#include "GaneshsAlgo.h"

std::string GaneshsAlgo::getPath()
{
	return "ganeshs ";
}
