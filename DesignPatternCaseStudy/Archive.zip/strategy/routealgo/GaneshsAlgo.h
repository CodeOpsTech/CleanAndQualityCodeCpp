#ifndef GANESHSALGO
#define GANESHSALGO

#include "RouteAlgos.h"
#include <string>

class GaneshsAlgo : public ShortestPathAlgo
{
public:
	virtual std::string getPath();
};



#endif	//#ifndef GANESHSALGO
