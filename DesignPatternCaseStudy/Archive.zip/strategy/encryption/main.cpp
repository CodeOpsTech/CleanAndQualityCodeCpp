#include "EncryptionTest.h"

int main(int argc, char **argv)
{
	Encryption *e = new Encryption();
	e->encrypt("hello");
	
	e->setEncryptionAlgorithm(new AESAlgorithm);
	e->encrypt("world");
    
    	return 0;
}
