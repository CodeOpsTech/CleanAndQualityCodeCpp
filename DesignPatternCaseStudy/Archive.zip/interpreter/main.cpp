#include "ExprEval.h"

int main(int argc, char **argv)
{
	// (10 + (30 - 20))  
	Expr *expr = new Plus(new Constant(10), new Sub(new Constant(30), new Constant(20)));
	std::cout << expr->eval() << std::endl;
	return 0;
}
