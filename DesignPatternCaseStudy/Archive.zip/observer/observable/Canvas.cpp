#include "Canvas.h"

void Canvas::update(Observable *arg0, void *arg1)
{
	std::cout << std::string("Canvas::update") << std::endl;
}
