#include "ShapeArchiver.h"

void ShapeArchiver::update(Observable *arg0, void *arg1)
{
	std::cout << std::string("ShapeArchiver::update") << std::endl;
}
