#include "ShapeArchiver.h"
#include "Circle.h"

void ShapeArchiver::update(Circle *circle)
{
	std::cout << std::string("ShapeArchiver::update") << std::endl;
}
