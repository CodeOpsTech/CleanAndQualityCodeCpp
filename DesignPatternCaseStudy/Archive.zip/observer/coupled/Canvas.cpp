#include "Canvas.h"
#include "Circle.h"

void Canvas::update(Circle *circle)
{
	std::cout << std::string("Canvas::update") << std::endl;
}
