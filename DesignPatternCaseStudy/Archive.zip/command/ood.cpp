#include <cstdlib>
#include <cstdio> 
#include <stack> 
using namespace std; 

using uchar = unsigned char; 

class Command {
protected: 
	stack<int> exec_stack;
public: 
	int operator()() { return result; }
};

class IMulCommand : Command {
public: 
	int operator()() {
        	int arg1 = exec_stack.top(); exec_stack.pop(); 
                int arg2 = exec_stack.top(); exec_stack.pop(); 
                int result = arg1 * arg2;
                exec_stack.push(result);
		return result; 
	}
};

class IDivCommand : Command {
public: 
	int operator()() {
        	int arg1 = exec_stack.top(); exec_stack.pop(); 
                int arg2 = exec_stack.top(); exec_stack.pop(); 
                int result = arg2 / arg1;
                exec_stack.push(result);
		return result; 
	}
};

class IAddCommand : Command {
public: 
	int operator()() {
        	int arg1 = exec_stack.top(); exec_stack.pop(); 
                int arg2 = exec_stack.top(); exec_stack.pop(); 
                int result = arg2 + arg1;
                exec_stack.push(result);
		return result; 
	}
};

class ISubCommand : Command {
public: 
	int operator()() {
        	int arg1 = exec_stack.top(); exec_stack.pop(); 
                int arg2 = exec_stack.top(); exec_stack.pop(); 
                int result = arg2 - arg1;
                exec_stack.push(result);
		return result; 
	}
};

class BIPushCommand : Command {
public: 
	int operator()(int val) {
		exec_stack.push(val); 
		return val; 
	}
};

enum { BIPUSH =	0x10, IMUL = 0x68, IDIV = 0x6c, IADD = 0x60, ISUB = 0x64 };

class BytecodeInterpreter { 
public: 
	int interpret(uchar bytecodes[], int num_bytecodes) {
		int pc = 0;  // program counter 
		int result = 0;
		while(pc < num_bytecodes) { 
		switch(bytecodes[pc]) {
		case BIPUSH: {
			BIPushCommand bipush;
			int val = bytecodes[++pc];
			result = bipush(val); 
                        break;
                        }
                case IMUL:  {
			IMulCommand imul; 
			result = imul(); 
                        break;
                        }
                case IDIV: {
			IDivCommand idiv; 
			result = idiv(); 
                        break;
                        }
                case IADD: {
			IAddCommand iadd; 
			result = iadd(); 
                        break;
                        }
                case ISUB: {
			ISubCommand isub; 
			result = isub(); 
                        break;
                        }
		} 
		pc++; 
		}
		return result; 
	} 
};

int main() {
	unsigned char bytecodes[] = { BIPUSH, 10, BIPUSH, 30, BIPUSH, 20, ISUB, IADD }; 
	int num_bytecodes = 8; 
	BytecodeInterpreter interpreter;
	int result = interpreter.interpret(bytecodes, num_bytecodes); 
	printf("The execution result is %d \n", result); 
} 
