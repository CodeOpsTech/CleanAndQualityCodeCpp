#include "ExpressionVisitor.h"

void JVMVisitor::visit(Constant *arg)
{
	std::cout << std::string("iload ") << arg->getVal() << std::endl;
}

void JVMVisitor::visit(Plus *plus)
{
	generate(plus->getLeft());
	generate(plus->getRight());
	std::cout << std::string("iadd") << std::endl;
}

void JVMVisitor::visit(Sub *sub)
{
	generate(sub->getLeft());
	generate(sub->getRight());
	std::cout << std::string("isub") << std::endl;
}

void JVMVisitor::generate(Expr *expr)
{
		expr->accept(this);
}

void DOTNETVisitor::visit(Constant *arg)
{
	std::cout << std::string("ldarg ") << arg->getVal() << std::endl;
}

void DOTNETVisitor::visit(Plus *plus)
{
	generate(plus->getLeft());
	generate(plus->getRight());
	std::cout << std::string("add") << std::endl;
}

void DOTNETVisitor::visit(Sub *sub)
{
	generate(sub->getLeft());
	generate(sub->getRight());
	std::cout << std::string("sub") << std::endl;
}

void DOTNETVisitor::generate(Expr *expr)
{
		expr->accept(this);
}

