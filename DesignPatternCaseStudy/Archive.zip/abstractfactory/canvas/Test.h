#pragma once

#include <string>
#include <vector>

class Test
{
public:
	static void main();
};
