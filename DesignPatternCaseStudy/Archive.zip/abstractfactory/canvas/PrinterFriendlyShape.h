#pragma once

#include "Shape.h"

class PrinterFriendlyShape : public Shape
{
};


