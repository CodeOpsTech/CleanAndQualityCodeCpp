#pragma once

class Shape
{
public:
	virtual void draw() = 0;
};
