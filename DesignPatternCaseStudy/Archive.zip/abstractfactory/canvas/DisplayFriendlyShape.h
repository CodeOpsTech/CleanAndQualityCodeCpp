#pragma once

#include "Shape.h"

class DisplayFriendlyShape : public Shape
{
};
