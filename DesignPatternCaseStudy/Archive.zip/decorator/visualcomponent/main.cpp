#include "DecoratorMain.h"

int main(int argc, char **argv)
{
	VisualComponent *comp = new TextView; // new ScrollDecorator(new BorderDecorator(new TextView)); 
	comp->draw();
}
