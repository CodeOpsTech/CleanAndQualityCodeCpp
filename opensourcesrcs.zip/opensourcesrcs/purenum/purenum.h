// ------------------
// Purenum 0.4e alpha
// ------------------
// purenum.h
// ------------------


#include "int.h"
#include "array.h"

