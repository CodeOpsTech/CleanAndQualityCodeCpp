//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by F:\Myprojects\DemoGL\DLL\Resources\resources.rc
//
#define IDD_STARTFORM                   101
#define IDI_ICON                        110
#define IDD_ABOUTFORM                   118
#define IDR_LENSFLARE                   125
#define IDR_DGLLOGOTGA                  127
#define IDB_APPLOGO                     140
#define IDC_BTNSTART                    1000
#define IDC_TBXTITLE                    1001
#define IDC_TBXRELEASEDBY               1002
#define IDC_RDBAPPFS                    1003
#define IDC_RDBAPPWIN                   1004
#define IDC_BTNABOUT                    1005
#define IDC_RDBDQ32                     1008
#define IDC_RDBDQ16                     1009
#define IDC_RDBTQ32                     1010
#define IDC_RDBTQ16                     1011
#define IDC_RDBSNDYES                   1012
#define IDC_RDBSNDNO                    1013
#define IDC_BTNCANCEL                   1014
#define IDC_VERSION                     1015
#define IDC_BTNWEBSITE                  1018
#define IDC_CMBRESOLUTION               1020
#define IDC_OK                          1024
#define IDC_DGLLOGOBMP                  1025
#define IDC_CMBSOUNDDEVICES             1030
#define IDC_RDBSNDMONO                  1031
#define IDC_RDBSNDSTEREO                1032
#define IDC_RDBSND8BIT                  1033
#define IDC_RDBSND16BIT                 1034
#define IDC_CHKSNDLOWQ                  1036
#define IDC_CHKREGSAVE                  1038
#define IDC_GREYBAR                     1039
#define IDC_APPLOGO                     1041
#define IDC_CHKA3D                      1042
#define IDC_CHKEAX                      1043
#define IDC_CHKRESCALETEX               1044
#define IDC_SLVOLUME                    1045
#define IDC_TBXVOLUME                   1046
#define IDC_LBLVOLMIN                   1047
#define IDC_LBLVOLMAX                   1048

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        143
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1049
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
