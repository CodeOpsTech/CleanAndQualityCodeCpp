/*************************************************
* Memory Locking Functions Source File           *
* (C) 1999-2001 The OpenCL Project               *
*************************************************/

#include <opencl/util.h>

namespace OpenCL {

/*************************************************
* Memory Locking Functions                       *
*************************************************/
void lock_mem(void* ptr, u32bit bytes)
   {
   }

void unlock_mem(void* ptr, u32bit bytes)
   {
   }

}
