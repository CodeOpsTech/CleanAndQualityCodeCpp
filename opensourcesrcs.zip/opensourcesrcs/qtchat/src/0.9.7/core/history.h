#ifndef _HISTORY_H
#define _HISTORY_H

class History : public QList {
	public:
		History();

		
};

#endif	// _HISTORY_H
