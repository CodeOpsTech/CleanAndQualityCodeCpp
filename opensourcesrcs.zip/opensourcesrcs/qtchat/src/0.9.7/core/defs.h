#ifndef _DEFS_H
#define _DEFS_H

#define PROGRAM_NAME "QtChat"

#endif // _DEFS_H
