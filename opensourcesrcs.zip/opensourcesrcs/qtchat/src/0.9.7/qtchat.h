#ifndef _QTCHAT_H
#define _QTCHAT_H

#define APP_NAME "QtChat"
#define APP_VER AP_VER_STR

#endif	// _QTCHAT_H
